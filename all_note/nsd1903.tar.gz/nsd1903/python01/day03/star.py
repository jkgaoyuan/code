"""星星模块

该模块包含了一个全局变和一个函数
"""

hi = 'Hello World'

def pstar(n=30):
    "默认打印30个星号"
    print('*' * n)

if __name__ == '__main__':
    pstar()
