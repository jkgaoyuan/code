#!/root/nsd1903/bin/python

print('hello world!')
